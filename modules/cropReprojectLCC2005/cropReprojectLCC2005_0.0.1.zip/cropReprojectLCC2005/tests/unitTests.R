
# Please build your own test file from test-Template.R, and place it in tests folder
# please specify the package you need to run the sim function in the test files.

# to test all the test files in the tests folder:
test_dir("C:/Users/tmichele/Dropbox/Project SpaDES/SpaDES-modules/modules/cropReprojectLCC2005/tests/testthat")

# Alternative, you can use test_file to test individual test file, e.g.:
test_file("C:/Users/tmichele/Dropbox/Project SpaDES/SpaDES-modules/modules/cropReprojectLCC2005/tests/testthat/test-template.R")
